  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyC1dEZOvZ9FMY5rzudkF3SYXWOA-4wiAKc",
    authDomain: "ipl-project-aa084.firebaseapp.com",
    databaseURL: "https://ipl-project-aa084.firebaseio.com",
    storageBucket: "ipl-project-aa084.appspot.com",
    messagingSenderId: "87580928918"
  };
  firebase.initializeApp(config);
